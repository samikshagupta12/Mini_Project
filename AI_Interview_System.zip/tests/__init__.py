"""Tests package initialization."""

